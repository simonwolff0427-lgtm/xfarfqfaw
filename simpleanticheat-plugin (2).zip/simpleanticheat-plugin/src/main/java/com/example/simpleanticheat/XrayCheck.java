package com.example.simpleanticheat;

import org.bukkit.Material;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Heuristic X-ray detection: for every valuable ore a player mines, checks
 * whether any of its 6 neighboring blocks were either already open (air/
 * cave/liquid — meaning the player found it through normal exploring) or
 * previously mined by that same player (meaning they dug their way there).
 * If NONE of the neighbors qualify, the ore was mined "blind" — straight out
 * of solid, unexplored stone, which is the classic signature of using X-ray
 * to beeline for ore. Tracks a rolling blind-hit ratio per player and flags
 * once there's a large enough sample showing a high ratio.
 *
 * Like the other checks here, this is a heuristic and not proof on its own —
 * efficient branch-mining in a dead-straight line can occasionally look
 * similar. Tune thresholds in config.yml, and consider /sac info before
 * taking action on a single flag.
 */
public class XrayCheck implements Listener {

    private final SimpleAntiCheatPlugin plugin;
    private final AntiCheatManager manager;

    private final Map<UUID, Integer> totalOre = new LinkedHashMap<>();
    private final Map<UUID, Integer> blindOre = new LinkedHashMap<>();
    private final Map<UUID, LinkedHashSet<Long>> recentlyMined = new LinkedHashMap<>();

    public XrayCheck(SimpleAntiCheatPlugin plugin, AntiCheatManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!plugin.getConfig().getBoolean("xray.enabled", true)) return;

        Player player = event.getPlayer();
        Block block = event.getBlock();
        UUID id = player.getUniqueId();

        // Remember every block the player mines (not just ore) so future
        // neighbor checks recognize tunnels they've already dug.
        rememberMined(id, block.getLocation());

        List<String> oreNames = plugin.getConfig().getStringList("xray.ore-materials");
        if (oreNames.isEmpty()) {
            oreNames = List.of("DIAMOND_ORE", "DEEPSLATE_DIAMOND_ORE", "ANCIENT_DEBRIS",
                    "EMERALD_ORE", "DEEPSLATE_EMERALD_ORE");
        }
        if (!oreNames.contains(block.getType().name())) return;

        boolean exposed = isExposed(player, block);

        int total = totalOre.merge(id, 1, Integer::sum);
        int blind = blindOre.getOrDefault(id, 0);
        if (!exposed) {
            blind = blindOre.merge(id, 1, Integer::sum);
        }

        int minSample = plugin.getConfig().getInt("xray.min-sample-size", 6);
        double ratioThreshold = plugin.getConfig().getDouble("xray.blind-ratio-threshold", 0.75);

        if (total >= minSample) {
            double ratio = (double) blind / (double) total;
            if (ratio >= ratioThreshold) {
                totalOre.put(id, 0);
                blindOre.put(id, 0);
                manager.flag(player, "Xray");
            } else {
                // Keep the sample from growing forever; slide the window.
                totalOre.put(id, 0);
                blindOre.put(id, 0);
            }
        }
    }

    private boolean isExposed(Player player, Block oreBlock) {
        Block[] neighbors = {
                oreBlock.getRelative(1, 0, 0), oreBlock.getRelative(-1, 0, 0),
                oreBlock.getRelative(0, 1, 0), oreBlock.getRelative(0, -1, 0),
                oreBlock.getRelative(0, 0, 1), oreBlock.getRelative(0, 0, -1)
        };

        LinkedHashSet<Long> mined = recentlyMined.get(player.getUniqueId());

        for (Block n : neighbors) {
            Material type = n.getType();
            if (type == Material.AIR || type == Material.CAVE_AIR
                    || type == Material.WATER || type == Material.LAVA) {
                return true; // naturally open space — found this ore through normal exploring
            }
            if (mined != null && mined.contains(key(n.getLocation()))) {
                return true; // player already dug this neighboring spot themselves
            }
        }
        return false;
    }

    private void rememberMined(UUID id, Location loc) {
        int cap = plugin.getConfig().getInt("xray.tracked-positions-per-player", 500);
        LinkedHashSet<Long> set = recentlyMined.computeIfAbsent(id, k -> new LinkedHashSet<>());
        set.add(key(loc));
        while (set.size() > cap) {
            var it = set.iterator();
            it.next();
            it.remove();
        }
    }

    private long key(Location loc) {
        int x = loc.getBlockX();
        int y = loc.getBlockY();
        int z = loc.getBlockZ();
        return (((long) (x & 0x3FFFFFF)) << 38) | (((long) (y & 0xFFF)) << 26) | ((long) (z & 0x3FFFFFF));
    }
}
