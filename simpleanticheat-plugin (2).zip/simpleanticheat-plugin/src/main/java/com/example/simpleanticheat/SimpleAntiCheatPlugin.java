package com.example.simpleanticheat;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class SimpleAntiCheatPlugin extends JavaPlugin {

    private AntiCheatManager manager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        manager = new AntiCheatManager(this);

        MovementCheck movementCheck = new MovementCheck(this, manager);
        Bukkit.getScheduler().runTaskTimer(this, movementCheck, 20L, 20L); // every second

        ReachCheck reachCheck = new ReachCheck(this, manager);
        Bukkit.getPluginManager().registerEvents(reachCheck, this);

        XrayCheck xrayCheck = new XrayCheck(this, manager);
        Bukkit.getPluginManager().registerEvents(xrayCheck, this);

        ChatFilterCheck chatFilterCheck = new ChatFilterCheck(this, manager);
        Bukkit.getPluginManager().registerEvents(chatFilterCheck, this);

        var cmd = getCommand("sac");
        if (cmd != null) {
            SacCommand executor = new SacCommand(this, manager);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }

        getLogger().info("SimpleAntiCheat enabled. auto-punish=" + getConfig().getBoolean("options.auto-punish", true));
    }

    @Override
    public void onDisable() {
        if (manager != null) manager.saveOffenses();
    }

    public AntiCheatManager getManager() {
        return manager;
    }
}
