package com.example.simpleanticheat;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.List;

/**
 * Blocks chat messages containing any word/phrase from chat-filter.banned-words
 * in config.yml (you supply the list — nothing is hardcoded here) and, if
 * options.auto-punish is on, bans the sender immediately. The message is
 * always blocked from being sent regardless of the auto-punish toggle.
 */
public class ChatFilterCheck implements Listener {

    private final SimpleAntiCheatPlugin plugin;
    private final AntiCheatManager manager;

    public ChatFilterCheck(SimpleAntiCheatPlugin plugin, AntiCheatManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!plugin.getConfig().getBoolean("chat-filter.enabled", true)) return;

        List<String> bannedWords = plugin.getConfig().getStringList("chat-filter.banned-words");
        if (bannedWords.isEmpty()) return;

        String raw = PlainTextComponentSerializer.plainText().serialize(event.message());
        String normalizedMessage = normalize(raw);

        for (String word : bannedWords) {
            String normalizedWord = normalize(word);
            if (normalizedWord.isEmpty()) continue;

            if (normalizedMessage.contains(normalizedWord)) {
                event.setCancelled(true);
                Player player = event.getPlayer();
                int days = plugin.getConfig().getInt("chat-filter.ban-days", 30);
                manager.banForChat(player, days);
                return;
            }
        }
    }

    /**
     * Lowercases, applies a few common leetspeak substitutions, and strips
     * everything that isn't a letter — so spacing/punctuation tricks and
     * basic number-substitution tricks both still match.
     */
    private String normalize(String input) {
        String s = input.toLowerCase();
        s = s.replace('1', 'i')
                .replace('3', 'e')
                .replace('4', 'a')
                .replace('0', 'o')
                .replace('5', 's')
                .replace('@', 'a')
                .replace('7', 't');
        s = s.replaceAll("[^a-z]", "");
        return s;
    }
}
