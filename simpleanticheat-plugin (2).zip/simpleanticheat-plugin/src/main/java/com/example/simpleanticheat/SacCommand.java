package com.example.simpleanticheat;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

public class SacCommand implements CommandExecutor, TabCompleter {

    private final SimpleAntiCheatPlugin plugin;
    private final AntiCheatManager manager;

    public SacCommand(SimpleAntiCheatPlugin plugin, AntiCheatManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String msg(String key) {
        return plugin.getConfig().getString("messages.prefix", "") + plugin.getConfig().getString("messages." + key, key);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("simpleanticheat.admin")) {
            sender.sendMessage(color(msg("no-permission")));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage(color("&eUsage: /sac <reset|info|reload> [player]"));
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reset" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&eUsage: /sac reset <player>"));
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                manager.resetOffenses(target.getUniqueId());
                sender.sendMessage(color(msg("reset-done").replace("{player}", args[1])));
            }
            case "info" -> {
                if (args.length < 2) {
                    sender.sendMessage(color("&eUsage: /sac info <player>"));
                    return true;
                }
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                int count = manager.getOffenseCount(target.getUniqueId());
                sender.sendMessage(color(msg("info-format").replace("{player}", args[1]).replace("{count}", String.valueOf(count))));
            }
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage(color(msg("reloaded")));
            }
            default -> sender.sendMessage(color("&eUsage: /sac <reset|info|reload> [player]"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : new String[]{"reset", "info", "reload"}) {
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
            }
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("reset") || args[0].equalsIgnoreCase("info"))) {
            for (var p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) out.add(p.getName());
            }
        }
        return out;
    }
}
