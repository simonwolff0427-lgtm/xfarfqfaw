package com.example.simpleanticheat;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ReachCheck implements Listener {

    private final SimpleAntiCheatPlugin plugin;
    private final AntiCheatManager manager;

    private final Map<UUID, Double> reachVL = new HashMap<>();

    public ReachCheck(SimpleAntiCheatPlugin plugin, AntiCheatManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler(ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent event) {
        if (!plugin.getConfig().getBoolean("reach.enabled", true)) return;
        if (!(event.getDamager() instanceof Player attacker)) return;

        double distance = attacker.getEyeLocation().distance(event.getEntity().getLocation());
        double maxDistance = plugin.getConfig().getDouble("reach.max-distance", 4.2);

        UUID id = attacker.getUniqueId();
        double threshold = plugin.getConfig().getDouble("reach.violation-threshold", 6.0);
        double decay = plugin.getConfig().getDouble("reach.violation-decay-per-second", 1.0);

        double vl = reachVL.getOrDefault(id, 0.0);
        if (distance > maxDistance) {
            vl += (distance - maxDistance);
        } else {
            vl = Math.max(0, vl - decay);
        }
        reachVL.put(id, vl);

        if (vl >= threshold) {
            reachVL.put(id, 0.0);
            manager.flag(attacker, "Reach");
        }
    }
}
