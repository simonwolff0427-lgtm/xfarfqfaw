package com.example.simpleanticheat;

import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AntiCheatManager {

    private final SimpleAntiCheatPlugin plugin;
    private final Map<UUID, Integer> offenses = new HashMap<>();
    private final File offensesFile;

    public AntiCheatManager(SimpleAntiCheatPlugin plugin) {
        this.plugin = plugin;
        this.offensesFile = new File(plugin.getDataFolder(), "offenses.yml");
        loadOffenses();
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String msg(String key) {
        return plugin.getConfig().getString("messages.prefix", "") + plugin.getConfig().getString("messages." + key, key);
    }

    /**
     * Called by a check when a player has crossed its violation threshold.
     * Always notifies staff. If auto-punish is on, escalates: first lifetime
     * offense -> kick, every offense after that -> ban for the configured
     * number of days.
     */
    public void flag(Player player, String checkName) {
        int count = offenses.merge(player.getUniqueId(), 1, Integer::sum);
        saveOffenses();

        String alertMsg = color(msg("alert")
                .replace("{player}", player.getName())
                .replace("{check}", checkName)
                .replace("{count}", String.valueOf(count)));

        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("simpleanticheat.alerts")) {
                staff.sendMessage(alertMsg);
            }
        }
        Bukkit.getConsoleSender().sendMessage(alertMsg);
        plugin.getLogger().info("ALERT: " + player.getName() + " flagged for " + checkName + " (lifetime offense #" + count + ")");

        boolean autoPunish = plugin.getConfig().getBoolean("options.auto-punish", true);
        if (!autoPunish) return;

        if (count <= 1) {
            kick(player, checkName);
            broadcastStaff(color(msg("staff-kicked").replace("{player}", player.getName()).replace("{check}", checkName)));
        } else {
            int banDays = plugin.getConfig().getInt("options.ban-days", 30);
            ban(player, checkName, banDays);
            broadcastStaff(color(msg("staff-banned")
                    .replace("{player}", player.getName())
                    .replace("{check}", checkName)
                    .replace("{days}", String.valueOf(banDays))));
        }
    }

    /**
     * Called by the chat filter when a banned word is matched. Unlike flag(),
     * this always goes straight to a ban (no kick-first step) — gated only by
     * options.auto-punish, same safety toggle as everything else. The chat
     * message itself is blocked by the caller regardless of this toggle.
     */
    public void banForChat(Player player, int days) {
        int count = offenses.merge(player.getUniqueId(), 1, Integer::sum);
        saveOffenses();

        String alertMsg = color(msg("alert")
                .replace("{player}", player.getName())
                .replace("{check}", "Chat Filter")
                .replace("{count}", String.valueOf(count)));
        broadcastStaff(alertMsg);
        plugin.getLogger().info("ALERT: " + player.getName() + " flagged for Chat Filter (lifetime offense #" + count + ")");

        if (!plugin.getConfig().getBoolean("options.auto-punish", true)) return;

        Date expiry = new Date(System.currentTimeMillis() + Duration.ofDays(days).toMillis());
        Bukkit.getBanList(BanList.Type.NAME).addBan(player.getName(), "Prohibited language in chat", expiry, "SimpleAntiCheat");

        String banMsg = color(msg("chat-ban-message").replace("{days}", String.valueOf(days)));
        player.kickPlayer(banMsg);

        broadcastStaff(color(msg("staff-chat-banned")
                .replace("{player}", player.getName())
                .replace("{days}", String.valueOf(days))));
    }

    private void broadcastStaff(String message) {
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("simpleanticheat.alerts")) {
                staff.sendMessage(message);
            }
        }
        Bukkit.getConsoleSender().sendMessage(message);
    }

    private void kick(Player player, String checkName) {
        String kickMsg = color(msg("kick-message").replace("{check}", checkName));
        player.kickPlayer(kickMsg);
    }

    private void ban(Player player, String checkName, int days) {
        Date expiry = new Date(System.currentTimeMillis() + Duration.ofDays(days).toMillis());
        String reason = "Suspected cheating (" + checkName + ")";
        Bukkit.getBanList(BanList.Type.NAME).addBan(player.getName(), reason, expiry, "SimpleAntiCheat");

        String banMsg = color(msg("ban-message")
                .replace("{check}", checkName)
                .replace("{days}", String.valueOf(days)));
        player.kickPlayer(banMsg);
    }

    // ---------------------------------------------------------------
    // Offense persistence
    // ---------------------------------------------------------------

    public int getOffenseCount(UUID uuid) {
        return offenses.getOrDefault(uuid, 0);
    }

    public void resetOffenses(UUID uuid) {
        offenses.remove(uuid);
        saveOffenses();
    }

    private void loadOffenses() {
        if (!offensesFile.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(offensesFile);
        var section = yaml.getConfigurationSection("offenses");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                offenses.put(UUID.fromString(key), section.getInt(key));
            } catch (IllegalArgumentException ignored) {
                // skip malformed UUID keys
            }
        }
    }

    public void saveOffenses() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (var entry : offenses.entrySet()) {
            yaml.set("offenses." + entry.getKey(), entry.getValue());
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yaml.save(offensesFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save offenses.yml: " + e.getMessage());
        }
    }
}
