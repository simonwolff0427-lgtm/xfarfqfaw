package com.example.simpleanticheat;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Samples every online player's position once per second to catch sustained
 * excess horizontal speed and sustained unsupported airtime. Deliberately
 * coarse (not per-tick) to keep false positives from brief, normal movement
 * (jump arcs, knockback, etc.) down — but it WILL still misfire sometimes.
 * See the warning in config.yml.
 */
public class MovementCheck implements Runnable {

    private final SimpleAntiCheatPlugin plugin;
    private final AntiCheatManager manager;

    private final Map<UUID, Location> lastLocation = new HashMap<>();
    private final Map<UUID, Double> speedVL = new HashMap<>();
    private final Map<UUID, Integer> airborneSeconds = new HashMap<>();

    public MovementCheck(SimpleAntiCheatPlugin plugin, AntiCheatManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public void run() {
        var cfg = plugin.getConfig();
        boolean speedEnabled = cfg.getBoolean("speed.enabled", true);
        boolean flightEnabled = cfg.getBoolean("flight.enabled", true);

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            if (isExempt(player)) {
                lastLocation.remove(player.getUniqueId());
                airborneSeconds.remove(player.getUniqueId());
                continue;
            }

            UUID id = player.getUniqueId();
            Location now = player.getLocation();
            Location last = lastLocation.get(id);

            if (speedEnabled && last != null && last.getWorld() != null && last.getWorld().equals(now.getWorld())) {
                checkSpeed(player, last, now, cfg);
            }
            lastLocation.put(id, now);

            if (flightEnabled) {
                checkFlight(player, cfg);
            }
        }
    }

    private boolean isExempt(Player player) {
        GameMode gm = player.getGameMode();
        return gm == GameMode.CREATIVE
                || gm == GameMode.SPECTATOR
                || player.isFlying()
                || player.getAllowFlight()
                || player.isGliding()
                || player.isInsideVehicle()
                || player.isSwimming()
                || player.hasPotionEffect(PotionEffectType.LEVITATION)
                || player.hasPotionEffect(PotionEffectType.SLOW_FALLING);
    }

    private void checkSpeed(Player player, Location last, Location now, org.bukkit.configuration.file.FileConfiguration cfg) {
        double dx = now.getX() - last.getX();
        double dz = now.getZ() - last.getZ();
        double horizDistPerSecond = Math.sqrt(dx * dx + dz * dz);

        double maxAllowed = cfg.getDouble("speed.max-blocks-per-second", 8.5);
        // Give a little extra allowance per level of Speed potion effect.
        var speedEffect = player.getPotionEffect(PotionEffectType.SPEED);
        if (speedEffect != null) {
            maxAllowed += (speedEffect.getAmplifier() + 1) * 1.5;
        }

        UUID id = player.getUniqueId();
        double threshold = cfg.getDouble("speed.violation-threshold", 10.0);
        double decay = cfg.getDouble("speed.violation-decay-per-second", 1.0);

        double vl = speedVL.getOrDefault(id, 0.0);
        if (horizDistPerSecond > maxAllowed) {
            vl += (horizDistPerSecond - maxAllowed);
        } else {
            vl = Math.max(0, vl - decay);
        }
        speedVL.put(id, vl);

        if (vl >= threshold) {
            speedVL.put(id, 0.0);
            manager.flag(player, "Speed");
        }
    }

    private void checkFlight(Player player, org.bukkit.configuration.file.FileConfiguration cfg) {
        UUID id = player.getUniqueId();
        boolean suspicious = !player.isOnGround() && player.getFallDistance() == 0f;

        int thresholdSeconds = cfg.getInt("flight.airborne-seconds-threshold", 4);

        if (suspicious) {
            int count = airborneSeconds.getOrDefault(id, 0) + 1;
            airborneSeconds.put(id, count);
            if (count >= thresholdSeconds) {
                airborneSeconds.put(id, 0);
                manager.flag(player, "Flight");
            }
        } else {
            airborneSeconds.put(id, 0);
        }
    }
}
