# SimpleAntiCheat

A basic heuristic anti-cheat with three checks:

- **Speed** — flags sustained horizontal movement faster than normally possible
- **Flight** — flags sustained time spent airborne with no fall distance accruing (i.e. not actually falling, not on ground, no legitimate reason)
- **Reach** — flags melee hits landed from further away than physically possible
- **Xray** — flags a high ratio of valuable ore (diamond, ancient debris, emerald by default) mined "blind" — straight out of solid, unexplored stone with no adjacent open space or prior digging by that player, over a rolling sample
- **Chat filter** — blocks any message containing a word from `chat-filter.banned-words` in `config.yml` (empty by default — **you add the words you want blocked, including slurs**) and, unlike the other checks, bans **immediately** rather than kicking first. The message is always blocked, even in notify-only mode; only the automatic ban itself respects `options.auto-punish`. Basic leetspeak (1→i, 3→e, 4→a, 0→o, 5→s, @→a, 7→t) and spacing/punctuation tricks are normalized before matching, so "b a d-w0rd" still matches an entry for "badword"

### Setting up the chat filter

Open `config.yml`, find `chat-filter.banned-words`, and add the words you
want blocked, one per line:

```yaml
chat-filter:
  banned-words:
    - "put the word here"
    - "add more words here"
```

Every kick and ban message in this plugin already states the reason — the
chat filter's ban message is `"Banned for {days} days for using prohibited
language in chat."`, shown to the player and echoed to staff.

Every flag:
1. Sends an alert to every online player with `simpleanticheat.alerts` (default: op) and logs it to console
2. Increments that player's **lifetime offense count** (persisted across restarts)
3. If `options.auto-punish` is `true` (default): **kicks** them on their 1st lifetime offense, **bans them for `options.ban-days`** (default 30) on every offense after that

## ⚠️ Please read before turning auto-punish on for real

This is nowhere near as accurate as Grim or Vulcan (see the earlier
recommendation — seriously consider using one of those instead, or alongside
this). A hand-rolled heuristic check like this **will** false-positive on:

- Lag spikes / server hiccups
- Knockback, explosions, elytra launches
- Water currents, soul sand, ice, honey blocks
- Other plugins that grant speed/flight (even briefly, if they don't set
  `Player#setFlying`/`setAllowFlight` properly)
- Elevators, pistons, and other contraptions
- Xray specifically: efficient, dead-straight branch mining can occasionally
  resemble "blind" ore hits even when totally legitimate — this is the check
  most worth watching closely before trusting auto-punish on it

Given you're auto-**banning for 30 days** on a second flag, a false positive
is a real cost to a real player. Recommended path:

1. Leave `options.auto-punish: false` at first. You'll still get every alert
   in chat/console, with nobody kicked or banned.
2. Watch it for a few days of normal play. Note which players/situations
   trigger alerts that are obviously not cheating.
3. Loosen the relevant thresholds in `config.yml` (raise
   `max-blocks-per-second`, `airborne-seconds-threshold`, `max-distance`, or
   the `violation-threshold` values) until false alerts mostly stop.
4. Only then set `auto-punish: true`.

## Commands

All require `simpleanticheat.admin` (default: op).

| Command | Effect |
|---|---|
| `/sac info <player>` | Shows a player's lifetime offense count |
| `/sac reset <player>` | Clears a player's offense count back to 0 (use this to undo a mistaken flag before their next offense would be a ban) |
| `/sac reload` | Reloads config.yml without restarting |

## Building

Same process as the other plugins: upload this whole folder as a zip to a
GitHub repo with `.github/workflows/build.yml` (already included), let
Actions build `SimpleAntiCheat-1.0.0.jar`, download it from the Artifacts
section.
